public class SecondProblem {
    int finderGDP(){
        return 0;
    }

}
